const settings = {
  packname: 'Gideon',
  author: '‎',
  botName: "Gideon",
  botOwner: 'Praise', // Your name
  ownerNumber: '2349121243622', //Set your number here without + symbol, just add country code & number without any space
  giphyApiKey: 'qnl7ssQChTdPjsKta2Ax2LMaGXz303tq',
  commandMode: "public",
  maxStoreMessages: 20, 
  storeWriteInterval: 10000,
  description: "This is a bot for managing group commands and automating tasks.",
  version: "2.1.10",
  updateZipUrl: "https://github.com/Gamerpraise/Gamerpraise/tree/main/Gideon_Ai.zip",
};

module.exports = settings;
